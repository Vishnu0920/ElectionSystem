Step 1: 

Change the following lines in both DB.py and Elections_Program.py as per the mysql user detail in the machine where this will be executed. Changing dbname is optional.

dbname = "elections"
dbuser = "root"
dbpassword = "a1s2d#"

Step 2:

Change the following lines in Elections_Program.py to set the Admin username and password

AdminUserName = "a"
AdminPassword = "p"

Step 3:

Execute DB.py

This will check if the given dbname exist in mysql and if not create the database and required tables

Step 4:

Execute Elections_Program.py and follow the options available in the program.

